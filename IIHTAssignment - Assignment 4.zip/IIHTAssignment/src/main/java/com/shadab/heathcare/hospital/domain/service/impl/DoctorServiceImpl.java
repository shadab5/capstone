package com.shadab.heathcare.hospital.domain.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.shadab.heathcare.hospital.domain.Exception.ResourceNotFoundException;
import com.shadab.heathcare.hospital.domain.entity.Doctor;
import com.shadab.heathcare.hospital.domain.repository.DoctorRepository;
import com.shadab.heathcare.hospital.domain.service.DoctorService;

@Service
public class DoctorServiceImpl implements DoctorService{
	
	@Autowired
	private DoctorRepository<?> doctorRepository;

	@Override
	@Cacheable(value="doctor", key="#doctor")
	public Doctor getDoctorById(int id) {
		
		if(doctorRepository.findById(id)== null) {
			throw new ResourceNotFoundException("Doctor","id",id);
		}
		
		Doctor existingDoctor = doctorRepository.findById(id);
		return existingDoctor;
	}

	@Override
	@CachePut(value="doctor", key="#doctor")
	public Doctor updateDoctorById(Doctor doctor, int id) {
		
		if(doctorRepository.findById(id)== null) {
			throw new ResourceNotFoundException("Doctor","id",id);
		}
		
		Doctor existingDoctor = doctorRepository.findById(id);//.orElseThrow(()-> new ResourceNotFoundException("Doctor","id",id));
	
		existingDoctor.setName(doctor.getName());
		existingDoctor.setExperience(doctor.getExperience());
		existingDoctor.setConsultingFees(doctor.getConsultingFees());
		existingDoctor.setQualification(doctor.getQualification());
		existingDoctor.setSpecialization(doctor.getSpecialization());
		
		doctorRepository.save(existingDoctor);
		
		return existingDoctor;
	}

	@Override
	@CacheEvict(value = "doctor", key ="#doctor")
	public boolean deleteDoctorById(int id) {
		
		if(doctorRepository.findById(id)== null) {
			throw new ResourceNotFoundException("Doctor","id",id);
		}
		
		Doctor existingDoctor  = doctorRepository.findById(id);
		
		doctorRepository.delete(existingDoctor);
		return true;
	}

	@Override
	public Doctor createDoctor(Doctor doctor) {
		return doctorRepository.save(doctor);
	}

	@Override
	@Cacheable(value="doctor")
	public List<Doctor> getListOfDoctor() {
		return doctorRepository.list();
	}

}
